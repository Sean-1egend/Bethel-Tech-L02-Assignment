function arrayFilter(sentence){
    // FUNCTION CODE GOES HERE
    var convertSentence = sentence.split(" ");
    var fourLetterWords = [];
    for (var i = 0; i < convertSentence.length; i++) {
       if (convertSentence[i].length >= 4) {
        fourLetterWords.push(convertSentence[i]);
       }
    }
    return fourLetterWords.join(" ");
}
console.log(arrayFilter("London is a big city in the United Kingdom"));